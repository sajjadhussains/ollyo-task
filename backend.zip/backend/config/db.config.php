<?php

/*
return [
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'ollyo_task', 
    'username' => 'root',
    'password' => 'Sajjad@1',
];
*/

// <?php
// backend/config/db.config.php
return [
    'host' => 'sql303.infinityfree.com',
    'port' => '3306',
    'database' => 'if0_40436163_devices_simulator',
    'username' => 'if0_40436163',
    'password' => 'k1AiMINm8Ti8gjP',
];
